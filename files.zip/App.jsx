import { useState, useEffect } from "react";
import { THEME } from "./config/theme";
import FoodPicker from "./components/FoodPicker";
import WorkoutTab from "./components/WorkoutTab";
import StatsTab from "./components/StatsTab";
import CoachTab from "./components/CoachTab";

const TABS = [
  { id: "food",    label: "Nutriție",    emoji: "🍽️" },
  { id: "workout", label: "Antrenament", emoji: "💪" },
  { id: "stats",   label: "Statistici",  emoji: "📊" },
  { id: "coach",   label: "Coach AI",    emoji: "🤖" },
];

function injectTheme(mode) {
  const t = THEME[mode] || THEME.dark;
  const root = document.documentElement;
  Object.entries(t).forEach(([k, v]) => root.style.setProperty(k, v));
  document.body.style.background = t["--bg"];
  document.body.style.color = t["--text"];
  document.body.style.margin = "0";
  document.body.style.fontFamily = "'Nunito', 'Segoe UI', system-ui, sans-serif";
}

export default function App() {
  const [activeTab, setActiveTab] = useState("food");
  const [themeMode, setThemeMode] = useState(() => localStorage.getItem("nutritie_theme") || "dark");

  useEffect(() => {
    injectTheme(themeMode);
    localStorage.setItem("nutritie_theme", themeMode);
  }, [themeMode]);

  return (
    <div style={{ minHeight: "100vh", background: "var(--bg)", color: "var(--text)", transition: "background 0.3s, color 0.3s" }}>
      {/* header */}
      <header style={{ position: "sticky", top: 0, zIndex: 100, background: "var(--card)", borderBottom: "1px solid var(--border)", padding: "12px 16px", display: "flex", alignItems: "center", justifyContent: "space-between", backdropFilter: "blur(10px)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ fontSize: 24 }}>🥗</span>
          <span style={{ fontWeight: 900, fontSize: 18, background: "linear-gradient(135deg, var(--accent), var(--accent2))", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", letterSpacing: "-0.5px" }}>
            Nutriție AI
          </span>
        </div>
        <button
          onClick={() => setThemeMode((m) => (m === "dark" ? "light" : "dark"))}
          style={{ background: "none", border: "1px solid var(--border)", borderRadius: 8, padding: "4px 10px", cursor: "pointer", fontSize: 16, color: "var(--text-muted)" }}
        >
          {themeMode === "dark" ? "☀️" : "🌙"}
        </button>
      </header>

      {/* content */}
      <main style={{ maxWidth: 480, margin: "0 auto", padding: "16px 16px 100px" }}>
        {activeTab === "food"    && <FoodPicker />}
        {activeTab === "workout" && <WorkoutTab />}
        {activeTab === "stats"   && <StatsTab />}
        {activeTab === "coach"   && <CoachTab />}
      </main>

      {/* bottom nav */}
      <nav style={{ position: "fixed", bottom: 0, left: 0, right: 0, zIndex: 100, background: "var(--card)", borderTop: "1px solid var(--border)", display: "flex", justifyContent: "space-around", padding: "8px 0 max(8px, env(safe-area-inset-bottom))", backdropFilter: "blur(12px)" }}>
        {TABS.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              style={{ background: "none", border: "none", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", gap: 3, padding: "4px 12px", borderRadius: 10, color: isActive ? "var(--accent)" : "var(--text-muted)", fontFamily: "inherit", transition: "color 0.2s" }}
            >
              <span style={{ fontSize: 20 }}>{tab.emoji}</span>
              <span style={{ fontSize: 10, fontWeight: isActive ? 700 : 400, whiteSpace: "nowrap" }}>{tab.label}</span>
              {isActive && <div style={{ width: 4, height: 4, borderRadius: "50%", background: "var(--accent)" }} />}
            </button>
          );
        })}
      </nav>
    </div>
  );
}
